# PARAMO Ecuador Public Results Dataset v1.1.0

This dataset contains the curated public results used by the **PARAMO Ecuador Results Explorer** for two long-term power-system planning applications:

- **Ecuador 24-Bus National Planning Case:** REF, BRIDGE and NZT pathways under Baseline and Adverse hydrology, including ensemble summaries, representative operational trajectories, generation expansion, reservoir indicators, emissions, ENS and cost metrics.
- **Ecuador 6-Bus Reduced Planning Case:** BAU and REN100 under Normal and Extreme hydrology, including generation/transmission expansion, corridor utilization, reservoir operation, emissions, ENS and cost metrics.

## Fuel-resolved 6-Bus results

The 6-bus public distribution preserves the original `FossilThermal` reporting category and adds a validated fuel-resolved layer for **diesel**, **fuel oil/residual** and **natural gas**. The reconstruction uses generator-level source-fuel traceability and reproduces the published `FossilThermal` aggregate for all four cases and every year from 2025 to 2050 within listing-output precision. Fuel-resolved tables are provided for installed capacity, capacity additions, annual generation and CO₂ emissions.

## Contents

- `data/cases/ecuador_24bus/` — national-case public results.
- `data/cases/ecuador_6bus/` — reduced-case public results, including fuel-resolved tables and fuel taxonomy.
- `data/geography/` — public planning-network geography, canonical zones and international interconnections.
- `data/metadata/` — case registry, metric definitions, data dictionary, scenario catalog and validation records.
- `METHODOLOGY.md`, `DATA_PROVENANCE.md`, `LIMITATIONS.md` — interpretation and provenance.
- `DATASET_MANIFEST.csv` — SHA-256 file manifest.

## Citation

Guamán Cuenca, W. (2026). *PARAMO Ecuador Public Results Dataset* (Version 1.1.0) [Data set].

Associated methodology:

Guamán, W., Benalcazar, P., Cordova-Garcia, J., & Torres, M. (2025). *An integrated framework for the optimal expansion of hydro-dependent power systems under water-resource uncertainty*. **Energy Conversion and Management: X, 28**, 101297. https://doi.org/10.1016/j.ecmx.2025.101297

## Licensing

PARAMO-derived public result tables and original documentation are distributed under **CC BY 4.0**. Third-party reference data remain subject to their original terms. The private PARAMO optimization implementation, private InputData workbooks, GDX/LST outputs and solver logs are not included.
