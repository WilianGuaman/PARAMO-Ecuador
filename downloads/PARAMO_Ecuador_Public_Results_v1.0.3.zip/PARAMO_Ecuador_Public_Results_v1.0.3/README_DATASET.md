# PARAMO Ecuador Public Results Dataset

**PARAMO — Planning And Resource Allocation under Multi-scenario Optimization**

Version **1.0.3** of the curated public results dataset used by the PARAMO Ecuador Results Explorer.

The distribution contains results for two PARAMO applications:

- **Ecuador 24-Bus National Planning Case** — REF, BRIDGE and NZT pathways under Baseline (100 realizations) and Adverse (5 realizations) hydrological conditions.
- **Ecuador 6-Bus Reduced Planning Case** — BAU and REN100 pathways under Normal and Extreme hydrology, including corridor-level transmission results.

The dataset also contains the public geographic crosswalk, explicit Colombia and Peru interconnection records, the 6-bus model-to-canonical zone crosswalk, metric definitions, scenario metadata, provenance documentation and citation information.

The PARAMO optimization implementation, private InputData workbooks, GDX/LST files, solver logs and other non-public research assets are not distributed.

Interactive explorer: https://wilianguaman.github.io/PARAMO-Ecuador/

Repository: https://github.com/WilianGuaman/PARAMO-Ecuador

For interpretation and reuse, consult `docs/DATA_PROVENANCE.md`, `docs/LIMITATIONS.md`, `CITATION.cff` and `LICENSES.md`.
