# PARAMO Ecuador Public Results Dataset

Curated public data for the **PARAMO Ecuador Results Explorer**.

**Version:** 1.0.0  
**Creator:** Wilian Guamán Cuenca  
**Explorer:** https://wilianguaman.github.io/PARAMO-Ecuador/  
**Repository:** https://github.com/WilianGuaman/PARAMO-Ecuador

## Contents

- Ecuador 24-Bus National Planning Case — REF, BRIDGE and NZT under Baseline and Adverse hydrology.
- Ecuador 6-Bus Reduced Planning Case — BAU and REN100 under Normal and Extreme hydrology.
- Generation expansion, operation, hydrology, reservoirs, CO₂, ENS and cost outputs.
- Corridor-level transmission outputs for the 6-bus case.
- Geospatial crosswalks and reference-system context from the Ecuador Power DataHub.
- Metric definitions, case manifests, scenario catalog and provenance metadata.

## Citation

> Guamán Cuenca, W. (2026). *PARAMO Ecuador Results Explorer: Planning And Resource Allocation under Multi-scenario Optimization* (Version 1.0.0) [Software and public research results]. GitHub. https://github.com/WilianGuaman/PARAMO-Ecuador

Foundational methodology: https://doi.org/10.1016/j.ecmx.2025.101297

## License

PARAMO-derived data, original figures and documentation are distributed under **CC BY 4.0**, subject to the component-level terms in `LICENSE-DATA.md`. Third-party source records retain their original terms.
