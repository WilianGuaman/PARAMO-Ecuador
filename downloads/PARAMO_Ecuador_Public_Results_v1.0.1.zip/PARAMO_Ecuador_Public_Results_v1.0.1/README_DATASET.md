# PARAMO Ecuador Public Results Dataset v1.0.1

Curated public results used by the PARAMO Ecuador Results Explorer.

## Study cases

- Ecuador 24-Bus National Planning Case: REF, BRIDGE and NZT under Baseline and Adverse hydrology.
- Ecuador 6-Bus Reduced Planning Case: BAU and REN100 under Normal and Extreme hydrology.

The dataset includes planning results, uncertainty statistics, geography, Colombia/Peru external-system context, a canonical 6-bus zone-code crosswalk, metric definitions and provenance documentation.

The PARAMO optimization implementation, private InputData workbooks, GDX/LST files and solver logs are not included.

Citation and license information are provided in `CITATION.cff`, `docs/CITATION.md` and `LICENSES.md`.
